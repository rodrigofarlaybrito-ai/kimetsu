package com.kimetsumod;

import com.kimetsumod.registry.ModCreativeTabs;
import com.kimetsumod.registry.ModEntities;
import com.kimetsumod.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(KimetsuMod.MODID)
public class KimetsuMod {
    public static final String MODID = "kimetsumod";

    public KimetsuMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModCreativeTabs.TABS.register(bus);
    }
}
