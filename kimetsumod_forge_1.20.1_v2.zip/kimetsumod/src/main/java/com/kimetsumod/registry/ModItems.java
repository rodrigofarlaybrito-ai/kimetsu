package com.kimetsumod.registry;

import com.kimetsumod.KimetsuMod;
import com.kimetsumod.breathing.Breathing;
import com.kimetsumod.item.KimetsuArmorMaterial;
import com.kimetsumod.item.NichirinSwordItem;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, KimetsuMod.MODID);

    public static final RegistryObject<Item> SCARLET_IRON_SAND =
            ITEMS.register("scarlet_iron_sand", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> SCARLET_IRON_INGOT =
            ITEMS.register("scarlet_iron_ingot", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> DEMON_BLOOD =
            ITEMS.register("demon_blood", () -> new Item(new Item.Properties()));

    /** Uma espada Nichirin para cada respiração. */
    public static final Map<Breathing, RegistryObject<Item>> NICHIRIN = new EnumMap<>(Breathing.class);

    static {
        for (Breathing breathing : Breathing.values()) {
            NICHIRIN.put(breathing, ITEMS.register("nichirin_" + breathing.id,
                    () -> new NichirinSwordItem(breathing, new Item.Properties())));
        }
    }

    private static RegistryObject<Item> armor(String name, KimetsuArmorMaterial material, ArmorItem.Type type) {
        return ITEMS.register(name, () -> new ArmorItem(material, type, new Item.Properties()));
    }

    // Uniforme de Caçador de Demônios
    public static final RegistryObject<Item> SLAYER_HELMET =
            armor("slayer_helmet", KimetsuArmorMaterial.SLAYER, ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> SLAYER_CHESTPLATE =
            armor("slayer_chestplate", KimetsuArmorMaterial.SLAYER, ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> SLAYER_LEGGINGS =
            armor("slayer_leggings", KimetsuArmorMaterial.SLAYER, ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> SLAYER_BOOTS =
            armor("slayer_boots", KimetsuArmorMaterial.SLAYER, ArmorItem.Type.BOOTS);

    // Roupas de Oni
    public static final RegistryObject<Item> ONI_HELMET =
            armor("oni_helmet", KimetsuArmorMaterial.ONI, ArmorItem.Type.HELMET);
    public static final RegistryObject<Item> ONI_CHESTPLATE =
            armor("oni_chestplate", KimetsuArmorMaterial.ONI, ArmorItem.Type.CHESTPLATE);
    public static final RegistryObject<Item> ONI_LEGGINGS =
            armor("oni_leggings", KimetsuArmorMaterial.ONI, ArmorItem.Type.LEGGINGS);
    public static final RegistryObject<Item> ONI_BOOTS =
            armor("oni_boots", KimetsuArmorMaterial.ONI, ArmorItem.Type.BOOTS);

    /** Haori de Hashira (peitoral), um para cada respiração. */
    public static final Map<Breathing, RegistryObject<Item>> HAORI = new EnumMap<>(Breathing.class);

    static {
        for (Breathing breathing : Breathing.values()) {
            HAORI.put(breathing, armor("haori_" + breathing.id,
                    KimetsuArmorMaterial.HAORI.get(breathing), ArmorItem.Type.CHESTPLATE));
        }
    }

    public static final RegistryObject<Item> ONI_SPAWN_EGG =
            ITEMS.register("oni_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.ONI, 0x4B3F5F, 0xC21E1E, new Item.Properties()));
    public static final RegistryObject<Item> HASHIRA_SPAWN_EGG =
            ITEMS.register("hashira_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.HASHIRA, 0x1E2230, 0xE6E6EB, new Item.Properties()));
    public static final RegistryObject<Item> ONI_KING_SPAWN_EGG =
            ITEMS.register("oni_king_spawn_egg", () -> new ForgeSpawnEggItem(ModEntities.ONI_KING, 0x46286E, 0xD2AA3C, new Item.Properties()));
}
