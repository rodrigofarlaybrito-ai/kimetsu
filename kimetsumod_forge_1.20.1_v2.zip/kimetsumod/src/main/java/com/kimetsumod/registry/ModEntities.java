package com.kimetsumod.registry;

import com.kimetsumod.KimetsuMod;
import com.kimetsumod.entity.HashiraEntity;
import com.kimetsumod.entity.OniEntity;
import com.kimetsumod.entity.OniKingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, KimetsuMod.MODID);

    public static final RegistryObject<EntityType<OniEntity>> ONI = ENTITIES.register("oni",
            () -> EntityType.Builder.of(OniEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(8)
                    .build("oni"));

    public static final RegistryObject<EntityType<HashiraEntity>> HASHIRA = ENTITIES.register("hashira",
            () -> EntityType.Builder.of(HashiraEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(8)
                    .build("hashira"));

    public static final RegistryObject<EntityType<OniKingEntity>> ONI_KING = ENTITIES.register("oni_king",
            () -> EntityType.Builder.of(OniKingEntity::new, MobCategory.MONSTER)
                    .sized(0.75F, 2.4F)
                    .clientTrackingRange(10)
                    .fireImmune()
                    .build("oni_king"));
}
