package com.kimetsumod.item;

import com.kimetsumod.registry.ModItems;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

public enum ModTiers implements Tier {
    NICHIRIN(3, 2200, 8.0F, 3.0F, 18);

    private final int level;
    private final int uses;
    private final float speed;
    private final float damage;
    private final int enchantValue;

    ModTiers(int level, int uses, float speed, float damage, int enchantValue) {
        this.level = level;
        this.uses = uses;
        this.speed = speed;
        this.damage = damage;
        this.enchantValue = enchantValue;
    }

    @Override public int getUses() { return uses; }
    @Override public float getSpeed() { return speed; }
    @Override public float getAttackDamageBonus() { return damage; }
    @Override public int getLevel() { return level; }
    @Override public int getEnchantmentValue() { return enchantValue; }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.of(ModItems.SCARLET_IRON_INGOT.get());
    }
}
