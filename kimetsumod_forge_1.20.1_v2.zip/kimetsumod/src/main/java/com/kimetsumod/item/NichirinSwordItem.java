package com.kimetsumod.item;

import com.kimetsumod.breathing.BreathData;
import com.kimetsumod.breathing.Breathing;
import com.kimetsumod.breathing.BreathingAbilities;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Espada Nichirin. Botão direito usa a forma selecionada,
 * Shift + botão direito troca de forma.
 */
public class NichirinSwordItem extends SwordItem {
    private final Breathing style;

    public NichirinSwordItem(Breathing style, Properties properties) {
        super(ModTiers.NICHIRIN, 3, -2.2F, properties);
        this.style = style;
    }

    public Breathing getStyle() {
        return style;
    }

    public int getForm(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        int form = tag == null ? 0 : tag.getInt("Form");
        return Math.floorMod(form, style.formCount());
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (player.isShiftKeyDown()) {
            int next = (getForm(stack) + 1) % style.formCount();
            stack.getOrCreateTag().putInt("Form", next);
            if (!level.isClientSide()) {
                player.displayClientMessage(Component.translatable("msg.kimetsumod.form_selected",
                        Component.translatable(style.formKey(next))), true);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        if (!level.isClientSide() && player instanceof ServerPlayer serverPlayer) {
            int index = getForm(stack);
            int cost = style.cost(index);
            if (BreathData.get(player) < cost) {
                player.displayClientMessage(Component.translatable("msg.kimetsumod.no_breath")
                        .withStyle(ChatFormatting.RED), true);
                return InteractionResultHolder.fail(stack);
            }
            BreathData.add(player, -cost);
            BreathingAbilities.perform((ServerLevel) level, serverPlayer, style, index);
            player.getCooldowns().addCooldown(this, style.cooldown(index));
            stack.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.kimetsumod.breathing",
                        Component.translatable(style.nameKey()).withStyle(Style.EMPTY.withColor(style.color)))
                .withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.kimetsumod.current_form",
                Component.translatable(style.formKey(getForm(stack)))).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.kimetsumod.how_to").withStyle(ChatFormatting.DARK_GRAY));
    }
}
