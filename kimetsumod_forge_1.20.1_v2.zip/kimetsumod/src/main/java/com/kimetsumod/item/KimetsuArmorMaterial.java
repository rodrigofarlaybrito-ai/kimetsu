package com.kimetsumod.item;

import com.kimetsumod.KimetsuMod;
import com.kimetsumod.breathing.Breathing;
import com.kimetsumod.registry.ModItems;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.crafting.Ingredient;

import java.util.EnumMap;
import java.util.Map;

/** Materiais de armadura do mod. Defesa na ordem: capacete, peitoral, calça, botas. */
public class KimetsuArmorMaterial implements ArmorMaterial {
    private static final int[] BASE_DURABILITY = {13, 15, 16, 11};

    public static final KimetsuArmorMaterial SLAYER =
            new KimetsuArmorMaterial("slayer", 22, new int[]{2, 6, 5, 2}, 14, 1.0F, 0.0F);
    public static final KimetsuArmorMaterial ONI =
            new KimetsuArmorMaterial("oni", 30, new int[]{3, 7, 6, 3}, 12, 2.0F, 0.1F);

    /** Um haori (peitoral) para cada respiração. */
    public static final Map<Breathing, KimetsuArmorMaterial> HAORI = new EnumMap<>(Breathing.class);

    static {
        for (Breathing breathing : Breathing.values()) {
            HAORI.put(breathing, new KimetsuArmorMaterial("haori_" + breathing.id, 28,
                    new int[]{0, 7, 0, 0}, 16, 2.0F, 0.05F));
        }
    }

    private final String name;
    private final int durabilityMultiplier;
    private final int[] defense;
    private final int enchantability;
    private final float toughness;
    private final float knockbackResistance;

    private KimetsuArmorMaterial(String name, int durabilityMultiplier, int[] defense, int enchantability,
                                 float toughness, float knockbackResistance) {
        this.name = name;
        this.durabilityMultiplier = durabilityMultiplier;
        this.defense = defense;
        this.enchantability = enchantability;
        this.toughness = toughness;
        this.knockbackResistance = knockbackResistance;
    }

    public static boolean isHaori(net.minecraft.world.item.ArmorMaterial material) {
        return HAORI.containsValue(material);
    }

    @Override
    public int getDurabilityForType(ArmorItem.Type type) {
        return BASE_DURABILITY[type.ordinal()] * durabilityMultiplier;
    }

    @Override
    public int getDefenseForType(ArmorItem.Type type) {
        return defense[type.ordinal()];
    }

    @Override
    public int getEnchantmentValue() {
        return enchantability;
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_LEATHER;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.of(ModItems.SCARLET_IRON_INGOT.get());
    }

    @Override
    public String getName() {
        return KimetsuMod.MODID + ":" + name;
    }

    @Override
    public float getToughness() {
        return toughness;
    }

    @Override
    public float getKnockbackResistance() {
        return knockbackResistance;
    }
}
