package com.kimetsumod.entity;

import com.kimetsumod.item.NichirinSwordItem;
import com.kimetsumod.registry.ModItems;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevelAccessor;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/**
 * Oni: regenera rápido, queima no sol e só morre de verdade para espadas Nichirin.
 * Cada oni nasce com uma Arte Demoníaca de Sangue (efeito aplicado ao acertar).
 */
public class OniEntity extends Monster {
    private static final EntityDataAccessor<Integer> ART =
            SynchedEntityData.defineId(OniEntity.class, EntityDataSerializers.INT);
    public static final int ART_COUNT = 4;

    private int noRegenTicks = 0;

    public OniEntity(EntityType<? extends OniEntity> type, Level level) {
        super(type, level);
        this.xpReward = 15;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 40.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.4D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.1D, false));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, HashiraEntity.class, true));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ART, 0);
    }

    public int getArt() {
        return this.entityData.get(ART);
    }

    public void setArt(int art) {
        this.entityData.set(ART, Math.floorMod(art, ART_COUNT));
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Art", getArt());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        setArt(tag.getInt("Art"));
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData spawnData, @Nullable CompoundTag dataTag) {
        setArt(this.getRandom().nextInt(ART_COUNT));
        // metade dos oni nasce vestindo a roupa de oni (8% de chance de dropar cada peça)
        if (this.getRandom().nextFloat() < 0.5F) {
            this.setItemSlot(EquipmentSlot.HEAD, new ItemStack(ModItems.ONI_HELMET.get()));
            this.setItemSlot(EquipmentSlot.CHEST, new ItemStack(ModItems.ONI_CHESTPLATE.get()));
            this.setItemSlot(EquipmentSlot.LEGS, new ItemStack(ModItems.ONI_LEGGINGS.get()));
            this.setItemSlot(EquipmentSlot.FEET, new ItemStack(ModItems.ONI_BOOTS.get()));
            for (EquipmentSlot slot : new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
                this.setDropChance(slot, 0.08F);
            }
        }
        return super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
    }

    @Override
    public void aiStep() {
        if (!this.level().isClientSide()) {
            if (this.isAlive() && this.isSunBurnTick()) {
                this.setSecondsOnFire(8);
            }
            if (noRegenTicks > 0) {
                noRegenTicks--;
            } else if (!this.isOnFire() && this.tickCount % 20 == 0 && this.getHealth() < this.getMaxHealth()) {
                this.heal(2.0F);
            }
        }
        super.aiStep();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide()) {
            if (source.getEntity() instanceof LivingEntity attacker
                    && attacker.getMainHandItem().getItem() instanceof NichirinSwordItem) {
                amount *= 1.5F;
                noRegenTicks = 200;
                // decapitação: com pouca vida, a Nichirin finaliza o oni
                if (this.getHealth() - amount <= this.getMaxHealth() * 0.2F) {
                    amount = this.getMaxHealth() + 1.0F;
                }
            } else if (!source.is(DamageTypeTags.IS_FIRE) && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
                amount *= 0.4F;
            }
        }
        return super.hurt(source, amount);
    }

    @Override
    public boolean doHurtTarget(Entity target) {
        boolean hurt = super.doHurtTarget(target);
        if (hurt && target instanceof LivingEntity living) {
            switch (getArt()) {
                case 0 -> living.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, 0));
                case 1 -> living.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
                case 2 -> {
                    living.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 100, 0));
                    living.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 60, 0));
                }
                default -> living.setSecondsOnFire(5);
            }
        }
        return hurt;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ZOMBIE_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ZOMBIE_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ZOMBIE_DEATH;
    }
}
