package com.kimetsumod.entity;

import com.kimetsumod.item.NichirinSwordItem;
import com.kimetsumod.registry.ModEntities;
import com.kimetsumod.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Rei dos Oni: chefe original inspirado no vilão da obra.
 * Fase 1: tentáculos (golpe em área a cada 5s) e invoca oni.
 * Fase 2 (abaixo de 50% de vida): mais rápido, regenera, golpes mais fortes.
 * Só a Nichirin impede a regeneração, e queima no sol como os outros.
 */
public class OniKingEntity extends Monster {
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.translatable("entity.kimetsumod.oni_king"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);

    private int tentacleCooldown = 100;
    private int summonCooldown = 300;
    private int noRegenTicks = 0;
    private boolean phase2 = false;

    public OniKingEntity(EntityType<? extends OniKingEntity> type, Level level) {
        super(type, level);
        this.xpReward = 200;
        this.bossEvent.setDarkenScreen(false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 400.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.28D)
                .add(Attributes.ATTACK_DAMAGE, 10.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.ARMOR, 8.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.15D, true));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, HashiraEntity.class, true));
    }

    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return false;
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (this.level().isClientSide() || !(this.level() instanceof ServerLevel level)) {
            return;
        }

        if (noRegenTicks > 0) {
            noRegenTicks--;
        } else if (this.tickCount % 20 == 0 && this.getHealth() < this.getMaxHealth()) {
            this.heal(phase2 ? 6.0F : 3.0F);
        }

        if (!phase2 && this.getHealth() <= this.getMaxHealth() * 0.5F) {
            enterPhase2(level);
        }

        LivingEntity target = this.getTarget();
        if (target == null || !target.isAlive()) {
            return;
        }

        if (--tentacleCooldown <= 0) {
            tentacleStrike(level);
            tentacleCooldown = phase2 ? 70 : 100;
        }
        if (--summonCooldown <= 0) {
            summonOni(level);
            summonCooldown = phase2 ? 400 : 600;
        }
    }

    private void enterPhase2(ServerLevel level) {
        phase2 = true;
        this.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.36D);
        this.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(15.0D);
        level.playSound(null, this.blockPosition(), SoundEvents.WITHER_SPAWN, this.getSoundSource(), 1.5F, 0.6F);
        level.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 1.0, getZ(), 8, 1.0, 1.0, 1.0, 0.0);
        this.bossEvent.setColor(BossEvent.BossBarColor.RED);
        this.bossEvent.setCreateWorldFog(true);
    }

    /** Tentáculos: dano e empurrão em todo mundo num raio de 6 blocos. */
    private void tentacleStrike(ServerLevel level) {
        double r = 6.0;
        AABB box = this.getBoundingBox().inflate(r, 2.0, r);
        float damage = phase2 ? 14.0F : 9.0F;
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box,
                x -> x != this && x.isAlive() && !(x instanceof OniEntity) && !(x instanceof OniKingEntity))) {
            if (e.distanceToSqr(this) > r * r) continue;
            e.hurt(this.damageSources().mobAttack(this), damage);
            Vec3 away = e.position().subtract(this.position()).normalize().scale(1.2);
            e.push(away.x, 0.4, away.z);
            e.hurtMarked = true;
        }
        for (int a = 0; a < 360; a += 15) {
            double rad = Math.toRadians(a);
            for (double d = 1.5; d <= r; d += 1.5) {
                level.sendParticles(ParticleTypes.SQUID_INK,
                        getX() + Math.cos(rad) * d, getY() + 0.3, getZ() + Math.sin(rad) * d, 1, 0.05, 0.05, 0.05, 0.0);
            }
        }
        level.playSound(null, this.blockPosition(), SoundEvents.RAVAGER_ATTACK, this.getSoundSource(), 1.5F, 0.7F);
    }

    private void summonOni(ServerLevel level) {
        int count = phase2 ? 3 : 2;
        for (int i = 0; i < count; i++) {
            OniEntity oni = ModEntities.ONI.get().create(level);
            if (oni == null) continue;
            double x = getX() + (this.random.nextDouble() - 0.5) * 8.0;
            double z = getZ() + (this.random.nextDouble() - 0.5) * 8.0;
            oni.moveTo(x, getY(), z, this.random.nextFloat() * 360F, 0F);
            oni.finalizeSpawn(level, level.getCurrentDifficultyAt(oni.blockPosition()), MobSpawnType.MOB_SUMMONED, null, null);
            oni.setTarget(this.getTarget());
            level.addFreshEntity(oni);
        }
        level.playSound(null, this.blockPosition(), SoundEvents.EVOKER_PREPARE_SUMMON, this.getSoundSource(), 1.5F, 0.6F);
    }

    @Override
    public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        boolean hurt = super.doHurtTarget(target);
        if (hurt && target instanceof LivingEntity living) {
            living.addEffect(new MobEffectInstance(MobEffects.WITHER, 100, phase2 ? 1 : 0));
            living.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
        }
        return hurt;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (!this.level().isClientSide()) {
            if (source.getEntity() instanceof LivingEntity attacker
                    && attacker.getMainHandItem().getItem() instanceof NichirinSwordItem) {
                amount *= 1.5F;
                noRegenTicks = 200;
            } else {
                amount *= 0.25F;
            }
        }
        return super.hurt(source, amount);
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(source, looting, recentlyHit);
        this.spawnAtLocation(new net.minecraft.world.item.ItemStack(ModItems.DEMON_BLOOD.get(), 8 + this.random.nextInt(8)));
        this.spawnAtLocation(new net.minecraft.world.item.ItemStack(ModItems.SCARLET_IRON_INGOT.get(), 4 + this.random.nextInt(4)));
    }

    // ---- barra de chefe ----
    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        this.bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        this.bossEvent.removePlayer(player);
    }

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        this.bossEvent.setProgress(this.getHealth() / this.getMaxHealth());
    }

    @Override
    public void setCustomName(net.minecraft.network.chat.Component name) {
        super.setCustomName(name);
        this.bossEvent.setName(this.getDisplayName());
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("Phase2", phase2);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.phase2 = tag.getBoolean("Phase2");
        if (this.hasCustomName()) {
            this.bossEvent.setName(this.getDisplayName());
        }
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.RAVAGER_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.RAVAGER_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.RAVAGER_DEATH;
    }
}
