package com.kimetsumod.breathing;

import com.kimetsumod.entity.HashiraEntity;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Executa as formas das respirações (sempre no servidor). */
public final class BreathingAbilities {
    private BreathingAbilities() {}

    public static void perform(ServerLevel level, ServerPlayer player, Breathing style, int index) {
        float dmg = style.damage(index);
        switch (style.formType(index)) {
            case SLASH -> slash(level, player, style, dmg);
            case SPIN -> spin(level, player, style, dmg);
            case DASH -> dash(level, player, style, dmg);
            case LEAP -> leap(level, player, style, dmg);
            case BUFF -> buff(level, player, style);
        }
        level.playSound(null, player.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP,
                SoundSource.PLAYERS, 1.0F, 0.9F + level.random.nextFloat() * 0.3F);
    }

    private static List<LivingEntity> targets(ServerLevel level, ServerPlayer p, AABB box) {
        return level.getEntitiesOfClass(LivingEntity.class, box, e ->
                e != p && e.isAlive()
                        && !(e instanceof Player)
                        && !(e instanceof HashiraEntity)
                        && !(e instanceof ArmorStand)
                        && !e.isAlliedTo(p));
    }

    private static void hit(ServerPlayer p, Breathing style, LivingEntity target, float dmg, double knockback) {
        if (!target.hurt(p.damageSources().playerAttack(p), dmg)) {
            return;
        }
        target.knockback(knockback, p.getX() - target.getX(), p.getZ() - target.getZ());
        switch (style) {
            case FLAME, SUN -> target.setSecondsOnFire(4);
            case THUNDER -> target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 2));
            case SERPENT -> target.addEffect(new MobEffectInstance(MobEffects.POISON, 80, 0));
            case INSECT, MOON -> target.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 0));
            case MIST -> target.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0));
            case LOVE -> target.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 80, 0));
            case SOUND -> target.addEffect(new MobEffectInstance(MobEffects.CONFUSION, 80, 0));
            default -> { }
        }
    }

    private static void fx(ServerLevel level, Breathing style, double x, double y, double z, int count, double spread, double speed) {
        level.sendParticles(style.particle, x, y, z, count, spread, spread, spread, speed);
    }

    private static void slash(ServerLevel level, ServerPlayer p, Breathing style, float dmg) {
        Vec3 start = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double length = 8.0;
        AABB box = new AABB(start, start.add(look.scale(length))).inflate(1.2);
        for (LivingEntity e : targets(level, p, box)) {
            Vec3 center = e.getBoundingBox().getCenter();
            double along = center.subtract(start).dot(look);
            if (along < 0 || along > length) continue;
            Vec3 closest = start.add(look.scale(along));
            if (closest.distanceToSqr(center) > 2.25) continue;
            hit(p, style, e, dmg, 0.6);
        }
        for (double d = 1.0; d < length; d += 0.9) {
            fx(level, style, start.x + look.x * d, start.y + look.y * d - 0.2, start.z + look.z * d, 3, 0.15, 0.01);
        }
        level.sendParticles(ParticleTypes.SWEEP_ATTACK, start.x + look.x * 1.5, start.y + look.y * 1.5 - 0.2, start.z + look.z * 1.5, 1, 0, 0, 0, 0);
    }

    private static void spin(ServerLevel level, ServerPlayer p, Breathing style, float dmg) {
        double r = 4.0;
        for (LivingEntity e : targets(level, p, p.getBoundingBox().inflate(r, 1.0, r))) {
            if (e.distanceToSqr(p) <= r * r) {
                hit(p, style, e, dmg, 0.9);
            }
        }
        for (int a = 0; a < 360; a += 20) {
            double rad = Math.toRadians(a);
            fx(level, style, p.getX() + Math.cos(rad) * r * 0.85, p.getY() + 0.9, p.getZ() + Math.sin(rad) * r * 0.85, 2, 0.1, 0.01);
        }
        level.sendParticles(ParticleTypes.SWEEP_ATTACK, p.getX(), p.getY() + 1.0, p.getZ(), 1, 0, 0, 0, 0);
    }

    private static void dash(ServerLevel level, ServerPlayer p, Breathing style, float dmg) {
        Vec3 look = p.getLookAngle();
        AABB box = p.getBoundingBox().expandTowards(look.scale(5.0)).inflate(1.0);
        for (LivingEntity e : targets(level, p, box)) {
            hit(p, style, e, dmg, 0.5);
        }
        Vec3 push = new Vec3(look.x, Math.max(look.y * 0.4, 0.1), look.z).normalize().scale(2.2);
        p.setDeltaMovement(push);
        p.hurtMarked = true;
        p.fallDistance = 0;
        for (int i = 0; i < 5; i++) {
            fx(level, style, p.getX() - look.x * i * 0.6, p.getY() + 1.0, p.getZ() - look.z * i * 0.6, 8, 0.3, 0.02);
        }
    }

    private static void leap(ServerLevel level, ServerPlayer p, Breathing style, float dmg) {
        Vec3 look = p.getLookAngle();
        for (LivingEntity e : targets(level, p, p.getBoundingBox().inflate(3.5, 1.5, 3.5))) {
            hit(p, style, e, dmg, 0.8);
        }
        p.setDeltaMovement(look.x * 0.8, 1.0, look.z * 0.8);
        p.hurtMarked = true;
        p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 80, 0, false, false));
        fx(level, style, p.getX(), p.getY() + 0.3, p.getZ(), 30, 0.8, 0.05);
    }

    private static void buff(ServerLevel level, ServerPlayer p, Breathing style) {
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 1));
        p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 1));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0));
        p.heal(4.0F);
        fx(level, style, p.getX(), p.getY() + 1.0, p.getZ(), 40, 0.8, 0.02);
    }
}
