package com.kimetsumod.breathing;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;

/** Fôlego do jogador, guardado nos dados persistentes do player (sem capabilities, leve). */
public final class BreathData {
    public static final int MAX = 100;
    private static final String KEY = "kimetsumod_breath";

    private BreathData() {}

    public static int get(Player player) {
        CompoundTag tag = player.getPersistentData();
        return tag.contains(KEY) ? tag.getInt(KEY) : MAX;
    }

    public static void set(Player player, int value) {
        player.getPersistentData().putInt(KEY, Math.max(0, Math.min(MAX, value)));
    }

    public static void add(Player player, int delta) {
        set(player, get(player) + delta);
    }
}
