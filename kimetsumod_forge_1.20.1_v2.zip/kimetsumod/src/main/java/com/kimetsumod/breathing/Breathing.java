package com.kimetsumod.breathing;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.SimpleParticleType;

/** As 14 respirações do mod. Cada uma tem 5 formas. */
public enum Breathing {
    WATER("water", 0x2E7DFF, ParticleTypes.SPLASH,
            FormType.SLASH, FormType.SPIN, FormType.DASH, FormType.LEAP, FormType.BUFF),
    FLAME("flame", 0xFF5A1F, ParticleTypes.FLAME,
            FormType.DASH, FormType.LEAP, FormType.SPIN, FormType.SLASH, FormType.BUFF),
    THUNDER("thunder", 0xFFD400, ParticleTypes.ELECTRIC_SPARK,
            FormType.DASH, FormType.SPIN, FormType.DASH, FormType.SLASH, FormType.LEAP),
    WIND("wind", 0x3DDC84, ParticleTypes.CLOUD,
            FormType.SPIN, FormType.SLASH, FormType.SLASH, FormType.LEAP, FormType.DASH),
    STONE("stone", 0x8A8A8A, ParticleTypes.ASH,
            FormType.SLASH, FormType.LEAP, FormType.BUFF, FormType.SPIN, FormType.SLASH),
    MIST("mist", 0xBFE6FF, ParticleTypes.WHITE_ASH,
            FormType.DASH, FormType.SPIN, FormType.SLASH, FormType.DASH, FormType.BUFF),
    LOVE("love", 0xFF7EB6, ParticleTypes.HEART,
            FormType.SLASH, FormType.SPIN, FormType.SLASH, FormType.DASH, FormType.LEAP),
    SERPENT("serpent", 0x3AA6A0, ParticleTypes.WITCH,
            FormType.SLASH, FormType.DASH, FormType.SPIN, FormType.SLASH, FormType.LEAP),
    SOUND("sound", 0xF2F2F2, ParticleTypes.NOTE,
            FormType.SPIN, FormType.SLASH, FormType.SPIN, FormType.SLASH, FormType.BUFF),
    INSECT("insect", 0x9B59D0, ParticleTypes.SPORE_BLOSSOM_AIR,
            FormType.DASH, FormType.DASH, FormType.SLASH, FormType.DASH, FormType.SPIN),
    FLOWER("flower", 0xFFA6C9, ParticleTypes.CHERRY_LEAVES,
            FormType.SPIN, FormType.SLASH, FormType.SPIN, FormType.DASH, FormType.LEAP),
    SUN("sun", 0xD92B2B, ParticleTypes.LAVA,
            FormType.SLASH, FormType.SPIN, FormType.LEAP, FormType.SLASH, FormType.BUFF),
    MOON("moon", 0xC9B6FF, ParticleTypes.END_ROD,
            FormType.SLASH, FormType.SLASH, FormType.SPIN, FormType.SLASH, FormType.SPIN),
    BEAST("beast", 0x6B7A8F, ParticleTypes.CRIT,
            FormType.DASH, FormType.SLASH, FormType.LEAP, FormType.SPIN, FormType.DASH);

    public final String id;
    public final int color;
    public final SimpleParticleType particle;
    private final FormType[] forms;

    Breathing(String id, int color, SimpleParticleType particle, FormType... forms) {
        this.id = id;
        this.color = color;
        this.particle = particle;
        this.forms = forms;
    }

    public int formCount() {
        return forms.length;
    }

    public FormType formType(int index) {
        return forms[index];
    }

    /** Dano da forma (cresce com o número da forma). */
    public float damage(int index) {
        return 6.0F + 2.5F * index;
    }

    /** Fôlego gasto (de 0 a 100). */
    public int cost(int index) {
        return 15 + 8 * index;
    }

    /** Recarga em ticks (20 ticks = 1 segundo). */
    public int cooldown(int index) {
        return 30 + 15 * index;
    }

    public String nameKey() {
        return "breathing.kimetsumod." + id;
    }

    public String formKey(int index) {
        return "form.kimetsumod." + id + "." + (index + 1);
    }
}
