package com.kimetsumod.breathing;

/** Tipo de efeito de cada forma de respiração. */
public enum FormType {
    SLASH,  // corte em linha à frente
    SPIN,   // ataque giratório em área
    DASH,   // avanço rápido que acerta quem está no caminho
    LEAP,   // salto com ataque em área
    BUFF    // aumenta força, velocidade e resistência
}
