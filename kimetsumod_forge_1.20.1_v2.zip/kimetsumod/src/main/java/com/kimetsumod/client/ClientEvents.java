package com.kimetsumod.client;

import com.kimetsumod.KimetsuMod;
import com.kimetsumod.entity.HashiraEntity;
import com.kimetsumod.entity.OniEntity;
import com.kimetsumod.entity.OniKingEntity;
import com.kimetsumod.registry.ModEntities;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = KimetsuMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientEvents {
    @SubscribeEvent
    public static void onRegisterRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.ONI.get(),
                ctx -> new KimetsuHumanoidRenderer<OniEntity>(ctx, "oni"));
        event.registerEntityRenderer(ModEntities.HASHIRA.get(),
                ctx -> new KimetsuHumanoidRenderer<HashiraEntity>(ctx, "hashira"));
        event.registerEntityRenderer(ModEntities.ONI_KING.get(),
                ctx -> new KimetsuHumanoidRenderer<OniKingEntity>(ctx, "oni_king", 1.25F));
    }
}
