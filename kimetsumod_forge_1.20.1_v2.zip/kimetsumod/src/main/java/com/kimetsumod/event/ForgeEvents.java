package com.kimetsumod.event;

import com.kimetsumod.KimetsuMod;
import com.kimetsumod.breathing.BreathData;
import com.kimetsumod.item.KimetsuArmorMaterial;
import com.kimetsumod.item.NichirinSwordItem;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ArmorMaterial;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = KimetsuMod.MODID)
public class ForgeEvents {

    /** Recupera o fôlego, aplica bônus de set e mostra a barra. Só roda 2x por segundo (leve). */
    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide()) {
            return;
        }
        Player player = event.player;
        if (player.tickCount % 10 != 0) {
            return;
        }
        if (BreathData.get(player) < BreathData.MAX) {
            BreathData.add(player, player.isSprinting() ? 1 : 3);
        }
        applySetBonuses(player);
        if (player.getMainHandItem().getItem() instanceof NichirinSwordItem sword) {
            int form = sword.getForm(player.getMainHandItem());
            player.displayClientMessage(Component.translatable("msg.kimetsumod.status",
                    BreathData.get(player), BreathData.MAX,
                    Component.translatable(sword.getStyle().formKey(form))), true);
        }
    }

    /**
     * Uniforme completo: Velocidade I.
     * Haori + resto do uniforme (Hashira): Força I e Velocidade II.
     * Roupa de oni completa: Força I e visão noturna, mas Fraqueza sob o sol.
     */
    private static void applySetBonuses(Player p) {
        if (wearingFullSet(p, KimetsuArmorMaterial.ONI)) {
            bonus(p, MobEffects.DAMAGE_BOOST, 0, 60);
            bonus(p, MobEffects.NIGHT_VISION, 0, 320);
            if (p.level().isDay() && p.level().canSeeSky(p.blockPosition())) {
                bonus(p, MobEffects.WEAKNESS, 0, 60);
            }
        } else if (isHashira(p)) {
            bonus(p, MobEffects.DAMAGE_BOOST, 0, 60);
            bonus(p, MobEffects.MOVEMENT_SPEED, 1, 60);
        } else if (wearingFullSet(p, KimetsuArmorMaterial.SLAYER)) {
            bonus(p, MobEffects.MOVEMENT_SPEED, 0, 60);
        }
    }

    private static void bonus(Player p, MobEffect effect, int amplifier, int duration) {
        p.addEffect(new MobEffectInstance(effect, duration, amplifier, true, false, true));
    }

    private static boolean is(ItemStack stack, ArmorMaterial material) {
        return stack.getItem() instanceof ArmorItem armor && armor.getMaterial() == material;
    }

    private static boolean wearingFullSet(Player p, ArmorMaterial material) {
        return is(p.getItemBySlot(EquipmentSlot.HEAD), material)
                && is(p.getItemBySlot(EquipmentSlot.CHEST), material)
                && is(p.getItemBySlot(EquipmentSlot.LEGS), material)
                && is(p.getItemBySlot(EquipmentSlot.FEET), material);
    }

    private static boolean isHashira(Player p) {
        ItemStack chest = p.getItemBySlot(EquipmentSlot.CHEST);
        return chest.getItem() instanceof ArmorItem armor
                && KimetsuArmorMaterial.isHaori(armor.getMaterial())
                && is(p.getItemBySlot(EquipmentSlot.HEAD), KimetsuArmorMaterial.SLAYER)
                && is(p.getItemBySlot(EquipmentSlot.LEGS), KimetsuArmorMaterial.SLAYER)
                && is(p.getItemBySlot(EquipmentSlot.FEET), KimetsuArmorMaterial.SLAYER);
    }
}
